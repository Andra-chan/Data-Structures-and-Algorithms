Lista Ordonata cu pozitie iterator - implementare folosind o LDI alocata dinamic

- operatia de inserare e implementata partial (doar cazul de adaugare inainte de primul element)